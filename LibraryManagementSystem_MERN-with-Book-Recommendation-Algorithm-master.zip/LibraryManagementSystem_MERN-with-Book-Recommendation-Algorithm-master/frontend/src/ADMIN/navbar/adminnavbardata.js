const navbarTitle = 'Library Management System'

const navbarImage = `/book-min.png`

const navbarLinks = [
  // {
  //   name: 'Home',
  //   url: '/admin',
  // },
  // {
  //   name: `Request's`,
  //   url: '/admin/booksrequests',
  // },
  // {
  //   name: 'Users',
  //   url: '/admin/viewusers',
  // },
  // {
  //   name: `Issue Book's`,
  //   url: '/admin/issuedbooks',
  // },
  // {
  //   name: `Return Book's`,
  //   url: '/admin/returnedbooks',
  // },
  // {
  //   name: `Logout`,
  //   url: '/admin/logout',
  // },
  // {
  //  name : '',
  //  url : ''
  // },
]

export default {
  navbarLinks,
  navbarTitle,
  navbarImage,
}
