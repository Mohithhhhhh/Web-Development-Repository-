### Populate Database

All the data is created for Starter Experience.

**import .json file on its corresponding mongo db collection**

### Login infos :

1. User Type : ADMIN_USER
   `email : admin@gmail.com`
   `password : admin`
